from typing import Tuple

class DatosMeteorologicos:
    def __init__(self, nombre_archivo: str):
        self.nombre_archivo = nombre_archivo

    def procesar_datos(self) -> Tuple[float, float, float, float, str]:
        temperaturas = []
        humedades = []
        presiones = []
        velocidades_viento = []
        direcciones_viento = []
        
        with open(self.nombre_archivo, 'r') as archivo:
            for linea in archivo:
                if linea.startswith("Temperatura:"):
                    temperatura = float(linea.split(":")[1].strip())
                    temperaturas.append(temperatura)
                elif linea.startswith("Humedad:"):
                    humedad = float(linea.split(":")[1].strip())
                    humedades.append(humedad)
                elif linea.startswith("Presión:"):
                    presion = float(linea.split(":")[1].strip())
                    presiones.append(presion)
                elif linea.startswith("Viento:"):
                    viento_info = linea.split(":")[1].strip().split(",")
                    velocidad_viento = float(viento_info[0].strip())
                    direccion_viento = viento_info[1].strip()
                    velocidades_viento.append(velocidad_viento)
                    direcciones_viento.append(direccion_viento)
        
     
        temperatura_promedio = sum(temperaturas) / len(temperaturas) if temperaturas else 0
        humedad_promedio = sum(humedades) / len(humedades) if humedades else 0
        presion_promedio = sum(presiones) / len(presiones) if presiones else 0
        velocidad_promedio_viento = sum(velocidades_viento) / len(velocidades_viento) if velocidades_viento else 0
        
     
        direcciones_grados = {
            "N": 0, "NNE": 22.5, "NE": 45, "ENE": 67.5,
            "E": 90, "ESE": 112.5, "SE": 135, "SSE": 157.5,
            "S": 180, "SSW": 202.5, "SW": 225, "WSW": 247.5,
            "W": 270, "WNW": 292.5, "NW": 315, "NNW": 337.5
        }
        direccion_grados = sum(direcciones_grados[d] for d in direcciones_viento) / len(direcciones_viento) if direcciones_viento else 0
        direccion_predominante = min(direcciones_grados, key=lambda d: abs(direcciones_grados[d] - direccion_grados))
        
        return (temperatura_promedio, humedad_promedio, presion_promedio, velocidad_promedio_viento, direccion_predominante)


nombre_archivo = "ruta/del/archivo/datos_meteorologicos.txt" 
datos = DatosMeteorologicos(nombre_archivo)
estadisticas = datos.procesar_datos()
print("Temperatura promedio:", estadisticas[0])
print("Humedad promedio:", estadisticas[1])
print("Presión promedio:", estadisticas[2])
print("Velocidad promedio del viento:", estadisticas[3])
print("Dirección predominante del viento:", estadisticas[4])



